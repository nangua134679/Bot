#pragma once

#define HTTP_SERVER "104.238.180.204"
#define HTTP_PORT 80

#define TFTP_SERVER "104.238.180.204"
